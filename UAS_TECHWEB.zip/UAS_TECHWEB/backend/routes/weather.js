require("dotenv").config();
const express = require("express");
const router = express.Router();
const axios = require("axios");
const mysql = require("mysql2");


// Koneksi ke database
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
});





// POST /api/cuaca - Ambil cuaca dari OpenWeather dan simpan ke database
router.post("/cuaca", async (req, res) => {
  const { kota } = req.body;
  const apiKey = process.env.WEATHER_API_KEY;

  try {
    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/weather?q=${kota}&appid=${apiKey}&units=metric&lang=id`
    );

    const data = response.data;

    // Simpan ke database
    db.query(
      "INSERT INTO riwayat_cuaca (nama_kota) VALUES (?)",
      [kota],
      (err) => {
        if (err) console.error("Gagal menyimpan ke database:", err);
      }
    );

    res.json({
      kota: data.name,
      suhu: data.main.temp,
      cuaca: data.weather[0].description,
    });
  } catch (err) {
    res
      .status(500)
      .json({ error: "Gagal mengambil data cuaca atau kota tidak ditemukan." });
  }
});

// GET /api/riwayat - Ambil data riwayat pencarian dari database
router.get("/riwayat", (req, res) => {
  db.query(
    "SELECT * FROM riwayat_cuaca ORDER BY waktu_pencarian DESC",
    (err, results) => {
      if (err)
        return res.status(500).json({ error: "Gagal mengambil riwayat" });
      res.json(results);
    }
  );
});

module.exports = router;
