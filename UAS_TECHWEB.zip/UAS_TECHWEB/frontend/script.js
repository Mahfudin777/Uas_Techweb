document.getElementById("form-cuaca").addEventListener("submit", async (e) => {
  e.preventDefault();

  const kota = document.getElementById("kota").value.trim();
  const hasil = document.getElementById("hasil");

  hasil.innerHTML = "⏳ Mengambil data...";
  hasil.classList.remove("hidden");

  try {
    const response = await fetch("http://localhost:3000/api/cuaca", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kota }),
    });

    const data = await response.json();

    if (response.ok) {
      hasil.innerHTML = `
            <h3>Cuaca di ${data.kota}</h3>
            <p>🌡️ Suhu: ${data.suhu}°C</p>
            <p>☁️ Cuaca: ${data.cuaca}</p>
          `;

      setBackgroundByWeather(data.cuaca);
    } else {
      hasil.innerHTML = `<p style="color:red;">❌ ${data.error}</p>`;
      document.body.className = ""; // reset background
    }
  } catch (error) {
    hasil.innerHTML = `<p style="color:red;">❌ Terjadi kesalahan jaringan.</p>`;
    document.body.className = ""; // reset background
  }
});

function generateClouds(type = "light") {
  const container = document.getElementById("cloud-container");
  container.innerHTML = "";

  const count = type === "light" ? 5 : 12;

  for (let i = 0; i < count; i++) {
    const cloud = document.createElement("div");
    cloud.className = "cloud";

    const size = Math.random() * 80 + 60;
    cloud.style.width = `${size}px`;
    cloud.style.height = `${size * 0.6}px`;
    cloud.style.top = `${Math.random() * 60 + 5}%`;
    cloud.style.left = `-${Math.random() * 200}px`;
    cloud.style.animationDuration = `${Math.random() * 40 + 60}s`;

    container.appendChild(cloud);
  }
}

function generateRain(
  selector,
  amount = 30,
  width = 2,
  height = 60,
  opacity = 0.2,
  duration = 0.6
) {
  const container = document.querySelector(selector);
  container.innerHTML = "";

  for (let i = 0; i < amount; i++) {
    const drop = document.createElement("span");
    drop.style.position = "absolute";
    drop.style.width = `${width}px`;
    drop.style.height = `${height}px`;
    drop.style.background = `rgba(255,255,255,${opacity})`;
    drop.style.left = `${Math.random() * 100}%`;
    drop.style.top = `${-Math.random() * 100}px`;
    drop.style.animation = `drop ${duration}s linear infinite`;
    drop.style.animationDelay = `${Math.random()}s`;

    container.appendChild(drop);
  }
}

function setBackgroundByWeather(cuaca) {
  const kondisi = cuaca.toLowerCase();
  const body = document.body;
  body.className = "";

  // Bersihkan kontainer
  document.getElementById("cloud-container").innerHTML = "";
  document.querySelector(".rain-light-container").innerHTML = "";
  document.querySelector(".rain").innerHTML = "";

  // Atur class & efek berdasarkan cuaca
  if (kondisi.includes("thunderstorm") || kondisi.includes("petir")) {
    body.classList.add("thunderstorm");
  } else if (kondisi.includes("drizzle") || kondisi.includes("gerimis")) {
    body.classList.add("drizzle");
  } else if (kondisi.includes("hujan") || kondisi.includes("rain")) {
    if (kondisi.includes("lebat") || kondisi.includes("heavy")) {
      body.classList.add("rain-heavy");
      generateRain(".rain", 40, 2, 60, 0.2, 0.6);
    } else {
      body.classList.add("rain-light");
      generateRain(".rain-light-container", 25, 1, 40, 0.1, 1.2);
    }
  } else if (kondisi.includes("salju") || kondisi.includes("snow")) {
    body.classList.add("snow");
  } else if (
    kondisi.includes("kabut") ||
    kondisi.includes("mist") ||
    kondisi.includes("asap") ||
    kondisi.includes("haze") ||
    kondisi.includes("debu") ||
    kondisi.includes("smoke")
  ) {
    body.classList.add("atmosphere");
  } else if (kondisi.includes("cerah") || kondisi.includes("clear")) {
    body.classList.add("clear");
  } else if (kondisi.includes("berawan") || kondisi.includes("cloud")) {
    if (kondisi.includes("sedikit") || kondisi.includes("light")) {
      body.classList.add("clouds-light");
      generateClouds("light");
    } else {
      body.classList.add("clouds-heavy");
      generateClouds("heavy");
    }
  } else {
    body.classList.add("default");
  }
}
  