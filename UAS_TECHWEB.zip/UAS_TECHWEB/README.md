# 🌤️ Aplikasi Cuaca Real-Time

Aplikasi web sederhana yang memungkinkan pengguna melihat informasi cuaca real-time berdasarkan nama kota. Data cuaca diambil dari API OpenWeatherMap dan hasil pencarian disimpan ke database MySQL.

## 🛠️ Teknologi
- Frontend: HTML, CSS, JavaScript
- Backend: Node.js + Express
- Database: MySQL
- API Cuaca: OpenWeatherMap

## 📁 Struktur Folder
